#pragma once

void jackClientInit(void);
void jackClientRun(void);
void jackClientSetIdleCallback(void(*cb)(void));
