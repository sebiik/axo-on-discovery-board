#pragma once

#include <stdbool.h>
#include <stdint.h>

static inline void setLed(enum Led led, bool state)
{
    (void)led;
    (void)state;
}
